<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <a href="/home" class="btn btn-default">Go Back</a>

        <h2 align="center">Book Room</h2><br><br>
    </div>
        <div class="col-md-8 col-md-offset-2">

            <?php echo $__env->make('messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="panel panel-default">
                <div class="panel-body">
                    <?php echo Form::open(['action' => 'RoomController@book', 'method' => 'POST']); ?>

                        <!-- Room Type -->
                        <div class="form-group">
                            <?php echo e(Form::label('type', 'Room Type', array('class' => 'control-label'))); ?> <br>
                            <?php echo e(Form::radio('type', 'Del')); ?> Deluxe <br>
                            <?php echo e(Form::radio('type', 'SupDel')); ?> Super Deluxe <br>
                            <?php echo e(Form::radio('type', 'Suite')); ?> Suite
                        </div>
                        <!--  Room choice  -->
                        <div class="form-group">
                            <?php echo e(Form::label('choice', 'Room Choice', array('class' => 'control-label'))); ?> <br>
                            <?php echo e(Form::radio('choice', 'ac')); ?> A/C <br>
                            <?php echo e(Form::radio('choice', 'nac')); ?> Non A/C <br>
                        </div>
                        <!-- Room view -->
                        <div class="form-group">
                            <?php echo e(Form::label('view', 'Room View', array('class' => 'control-label'))); ?> <br>
                            <?php echo e(Form::radio('view', 'garden')); ?> Garden View <br>
                            <?php echo e(Form::radio('view', 'mountain')); ?> Mountain View <br>
                        </div>
                        <!-- Check In -->
                        <div class="form-group">
                            <?php echo e(Form::label('checkIn', 'Check In', array('class' => 'control-label'))); ?> <br>
                            <?php echo e(Form::date('checkIn')); ?> <br>
                        </div>
                        <!-- Check In -->
                        <div class="form-group">
                            <?php echo e(Form::label('checkOut', 'Check Out', array('class' => 'control-label'))); ?> <br>
                            <?php echo e(Form::date('checkOut')); ?> <br>
                        </div>
                        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>