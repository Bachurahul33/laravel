<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <h2 align="center">Welcome, <?php echo e(Auth::user()->name); ?></h2><br><br>
    </div>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">

            <?php echo $__env->make('messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="panel panel-default">
                <div class="panel-heading text-center">Dashboard</div>

                <div class="panel-body">
                    <ul class="list-group">
                        <li class="list-group-item"><a href="/bookroom">Book room</a></li>
                        <li class="list-group-item"><a href="/view">View Reciepts</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>