<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <a href="/home" class="btn btn-default">Go Back</a>
        <h2 align="center">Reciepts</h2><br><br>
    </div>
    <?php if(count($bills) > 0): ?>
        <table class="table table-striped">
            <tr>
                <th>Booking ID</th>
                <th>Room No.</th>
                <th>Tariff</th>
                <th>Check In</th>
                <th>Check Out</th>
            </tr>
            <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($bill->bookingId); ?></td>
                <td><?php echo e($bill->roomNo); ?></td>
                <td><?php echo e($bill->cost); ?></td>
                <td><?php echo e($bill->checkIn); ?></td>
                <td><?php echo e($bill->checkOut); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php else: ?>
        <p class="text-center">No reciepts found</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>