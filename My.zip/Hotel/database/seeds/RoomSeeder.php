<?php

use Illuminate\Database\Seeder;

class RoomSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('rooms')->insert([
            'roomno' => '202',
            'tariff' => '3000',
            'type' => 'Suite',
            'choice' => 'nac',
            'view' => 'garden',
            'capacity' => '2',
        ]);
        DB::table('rooms')->insert([
            'roomno' => '204',
            'tariff' => '1000',
            'type' => 'Suite',
            'choice' => 'nac',
            'view' => 'mountain',
            'capacity' => '1',
        ]);
        DB::table('rooms')->insert([
            'roomno' => '205',
            'tariff' => '4000',
            'type' => 'Del',
            'choice' => 'ac',
            'view' => 'mountain',
            'capacity' => '2',
        ]);
        DB::table('rooms')->insert([
            'roomno' => '101',
            'tariff' => '5000',
            'type' => 'SupDel',
            'choice' => 'ac',
            'view' => 'mountain',
            'capacity' => '1',
        ]);
         DB::table('rooms')->insert([
            'roomno' => '403',
            'tariff' => '4000',
            'type' => 'Del',
            'choice' => 'ac',
            'view' => 'garden',
            'capacity' => '2',
        ]);
          DB::table('rooms')->insert([
            'roomno' => '402',
            'tariff' => '4000',
            'type' => 'Del',
            'choice' => 'nac',
            'view' => 'mountain',
            'capacity' => '2',
        ]);
           DB::table('rooms')->insert([
            'roomno' => '401',
            'tariff' => '4000',
            'type' => 'Del',
            'choice' => 'nac',
            'view' => 'garden',
            'capacity' => '2',
        ]);
           DB::table('rooms')->insert([
            'roomno' => '501',
            'tariff' => '6000',
            'type' => 'SupDel',
            'choice' => 'ac',
            'view' => 'garden',
            'capacity' => '2',
        ]);
           DB::table('rooms')->insert([
            'roomno' => '502',
            'tariff' => '2000',
            'type' => 'SupDel',
            'choice' => 'nac',
            'view' => 'mountain',
            'capacity' => '1',
        ]);
          
            DB::table('rooms')->insert([
            'roomno' => '702',
            'tariff' => '8000',
            'type' => 'Suite',
            'choice' => 'ac',
            'view' => 'mountain',
            'capacity' => '1',
        ]);
              DB::table('rooms')->insert([
            'roomno' => '705',
            'tariff' => '8000',
            'type' => 'Suite',
            'choice' => 'ac',
            'view' => 'mountain',
            'capacity' => '3',
        ]);
            DB::table('rooms')->insert([
            'roomno' => '701',
            'tariff' => '1000',
            'type' => 'Suite',
            'choice' => 'ac',
            'view' => 'garden',
            'capacity' => '2',
        ]);
    }
}
